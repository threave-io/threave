import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Cn6kALDM.js";import"./chunk-I66GZJ75-z7nq-Ky3.js";import"./chunk-NSK5VX7P-DrP5kt5S.js";import"./chunk-4I5QYGJK-D7UI1-5_.js";import"./chunk-WRU74C26-BEbWPpTi.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-CnBsw9CK.js";import"./chunk-2GRJ4B5K-BDeZJMPF.js";import"./chunk-XXDRQBXY-Y1lmGfHA.js";import"./chunk-KBJHAD2P-DZuCPrFK.js";import"./chunk-W5SLKNZC-CPUJnfUn.js";import"./chunk-QR6OTTB3-BTer8Nb7.js";import"./chunk-7Z6QIM7H-CZIbD41l.js";import"./chunk-J7OUQ5F2-B_t-jnqt.js";import"./chunk-ZIRB5QZD-H-kepumB.js";import{r as t,t as n}from"./chunk-JQJVKLGR-BijseC5C.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};