import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Cn6kALDM.js";import"./chunk-I66GZJ75-CaBw8qAK.js";import"./chunk-NSK5VX7P-DfwZhZRw.js";import"./chunk-4I5QYGJK-BhsXYPoK.js";import"./chunk-WRU74C26-WHgNhfCT.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-CTZuzIaX.js";import"./chunk-2GRJ4B5K-Bsircc0P.js";import"./chunk-XXDRQBXY-Y1lmGfHA.js";import"./chunk-KBJHAD2P-BZAOGHDz.js";import"./chunk-W5SLKNZC-Bdc97AXD.js";import"./chunk-QR6OTTB3-BO_of0yW.js";import"./chunk-7Z6QIM7H-5cPaO88F.js";import"./chunk-J7OUQ5F2-BHboDeDi.js";import"./chunk-ZIRB5QZD-H-kepumB.js";import{r as t,t as n}from"./chunk-JQJVKLGR-CjeMSLmv.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};