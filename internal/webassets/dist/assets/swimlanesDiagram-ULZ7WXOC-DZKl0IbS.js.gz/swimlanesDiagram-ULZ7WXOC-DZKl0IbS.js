import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Cn6kALDM.js";import"./chunk-I66GZJ75-Bbk5xVx-.js";import"./chunk-NSK5VX7P-CF_vghxb.js";import"./chunk-4I5QYGJK-BUGgTdFT.js";import"./chunk-WRU74C26-CZChTPh4.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-viPpfHNH.js";import"./chunk-2GRJ4B5K-CrYE9daP.js";import"./chunk-XXDRQBXY-Y1lmGfHA.js";import"./chunk-KBJHAD2P-BsRZEGg5.js";import"./chunk-W5SLKNZC-BZoT3BSn.js";import"./chunk-QR6OTTB3-Cldo4nAH.js";import"./chunk-7Z6QIM7H-D_QQ-6Tk.js";import"./chunk-J7OUQ5F2-Bu1ooYtu.js";import"./chunk-ZIRB5QZD-H-kepumB.js";import{r as t,t as n}from"./chunk-JQJVKLGR-bJIcAtIh.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};